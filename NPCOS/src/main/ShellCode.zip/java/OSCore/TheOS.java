package OSCore;
import Processes.Process;

public class TheOS
{
    public static void main(String[] args)
    {

    }
}
