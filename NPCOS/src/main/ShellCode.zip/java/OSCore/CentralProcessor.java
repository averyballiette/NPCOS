package OSCore;
import Processes.Process;

public class CentralProcessor
{
    Scheduler scheduler;
    OSControl oscontrol;

    public CentralProcessor()
    {
        scheduler = Scheduler.getInstance();
        oscontrol = OSControl.getInstance();
    }

    void run()
    {

    }
}
