package OSCore;

import Processes.Process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Scheduler {
    // Singleton instance
    private static Scheduler instance;
    OSControl osControl = OSControl.getInstance();
    ArrayList<Process> processQueue;

    //Singleton Methods
    public static Scheduler getInstance() {
        if (instance == null) {
            instance = new Scheduler();
        }
        return instance;
    }

    private Scheduler()
    {
        processQueue = new ArrayList<>();
    }

    // Method to add a process to the queue
    public void addProcess(Process process)
    {
    }

    // Method to get the next process depending on ScheduleType
    Process getNextProcess()
    {
    }

    public boolean isQueueEmpty()
    {

    }
}
