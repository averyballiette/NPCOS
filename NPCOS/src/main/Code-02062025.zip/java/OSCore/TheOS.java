package OSCore;

import OSCore.CentralProcessor;
import OSCore.OSControl;
import OSCore.Scheduler;
import Process.Process;

import java.util.ArrayList;

public class TheOS
{
    //add processes to queue
    static ArrayList<Process> processes = new ArrayList<>();

    public static void main(String[] args)
    {
        CentralProcessor cpu = new CentralProcessor();
        Scheduler scheduler = Scheduler.getInstance();
//        OSControl osControl = OSControl.getInstance();


        LoadProcesses(); //create new processes and load into CPU

        for (Process process : processes)
        {
            scheduler.addProcess(process); //place all processes in Scheduler
        }

        cpu.run();   //START the CPU

    }

    private static void LoadProcesses()
    {
        //processes with no prioity
        processes.add(new Process()); //user creates new process
        processes.add(new Process());

        //processes with priority
//        processes.add(new Proces("Program01.code", 5));
//        processes.add(new Proces("Program02.code",8));
//        processes.add(new Proces("Program01.code", 2));
//        processes.add(new Proces("Program02.code",7));

    }
}
