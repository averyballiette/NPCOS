package OSCore;

import Process.Process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Scheduler {
    // Singleton instance
    private static Scheduler instance;
    OSControl osControl = OSControl.getInstance();
    OSControl.Schedule_Type scheduleType;
    ArrayList<Process> processQueue;

    //Singleton Methods
    public static Scheduler getInstance() {
        if (instance == null) {
            instance = new Scheduler();
        }
        return instance;
    }

    private Scheduler() {
        this.scheduleType = osControl.getScheduleType(); // Default scheduler type
        processQueue = new ArrayList<>();
    }

    //Other Methods

    // Method to add a process to the queue
    public void addProcess(Process process)
    {
        processQueue.add(process);
    }

    public OSControl.Schedule_Type getScheduleType()
    {
        return scheduleType;
    }

    // Method to get the next process depending on ScheduleType
    Process getNextProcess() {
        if (processQueue.isEmpty()) {
            return null; // No processes in the queue
        }
        else
        {
            //roundRobin and firstComeFirstServe both have same algorithm at this point in code
            //both take turns, fcfs runs to completion on first attempt (controlled in CPU)
            //roundRobin may or may not run to completion on first or any subsequent attempt
            if (scheduleType == OSControl.Schedule_Type.ROUND_ROBIN || scheduleType == OSControl.Schedule_Type.FIRSTCOMEFIRSTSERVE)
            {
                // Every process gets an equal time quantum
                Process process= processQueue.get(0); //get first process on queue
                processQueue.remove(0); //remove it from the queue
                return process;
            }

            //PRIORITY SCHEDULER
            if (scheduleType == OSControl.Schedule_Type.PRIORITY)
            {
                //sort the queue based on Priority of each process
                //all processes with same/highest priority will be at top of queue
                Collections.sort(processQueue, new Comparator<Process>()
                {
                    @Override
                    public int compare(Process p1, Process p2) {
                        // Compare the priorities in descending order
                        return Integer.compare(p2.getProcessPriority(), p1.getProcessPriority());
                    }
                });

                //create a new temp list only including processes with the highest priority
                //then sort them based on remaining time
                //return the one from the top of the list
                int highestPriorty = processQueue.get(0).getProcessPriority();

                List<Process> highPriority = processQueue.stream()
                        .filter(process -> process.getProcessPriority() == highestPriorty)
                        .collect(Collectors.toList());

                Collections.sort(highPriority, new Comparator<Process>()
                {
                    @Override
                    public int compare(Process p1, Process p2) {
                        // Compare the remaining times in descending order
                        return Double.compare(p1.getRemainingTime(), p2.getRemainingTime());
                    }
                });

                Process process = highPriority.get(0); //get first process on queue
                processQueue.remove(0); //remove it from the queue
                return process;
            }

            //SHORTEST FIRST SCHEDULER
            if (scheduleType == OSControl.Schedule_Type.SHORTEST_FIRST)
            {
                Collections.sort(processQueue, new Comparator<Process>()
                {
                    @Override
                    public int compare(Process p1, Process p2) {
                        // Compare the remaining times in descending order
                        return Double.compare(p1.getRemainingTime(), p2.getRemainingTime());
                    }
                });

                Process process = processQueue.get(0); //get first process on queue
                processQueue.remove(0); //remove it from the queue
                return process;

            }
            return null;
        }
    }

    public boolean isQueueEmpty()
    {
        return processQueue.isEmpty();
    }
}
