package OSCore;

public class OSControl
{

    enum Schedule_Type {ROUND_ROBIN, PRIORITY, FIRSTCOMEFIRSTSERVE, SHORTEST_FIRST};
    private static OSControl instance;
    Double QUANTUM = 10.0;
    Integer NEXT_PROCESS_ID = 1000;
    Schedule_Type SCHEDULE_TYPE = Schedule_Type.ROUND_ROBIN;
    private Integer NextProcessID;
    private Double Quantum;
    static Schedule_Type ScheduleType;

    //Singleton Methods
    private OSControl()
    {
        NextProcessID = NEXT_PROCESS_ID;
        ScheduleType = SCHEDULE_TYPE;
        Quantum = QUANTUM;
    }

    public static OSControl getInstance()
    {
        if (instance == null)

        {
            instance = new OSControl();
        }
        return instance;
    }

    //Getters/Setters
    public Schedule_Type getScheduleType()
    {
        return SCHEDULE_TYPE;
    }

    public Double getQuantum()
    {
        return QUANTUM;
    }

    public Integer getNEXT_PROCESS_ID()
    {

        return NEXT_PROCESS_ID += 1;
    }
}
