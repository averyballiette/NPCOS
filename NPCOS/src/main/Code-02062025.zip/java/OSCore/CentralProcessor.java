package OSCore;


import Process.Process;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CentralProcessor
{
    Scheduler scheduler = Scheduler.getInstance();


    public CentralProcessor()
    {

    }

    void run()
    {
        while (!scheduler.isQueueEmpty())
        {
            Process process = scheduler.getNextProcess();

            //in this implementation, FCFS and SF both run to completion on first attempt
            if (scheduler.getScheduleType() == OSControl.Schedule_Type.FIRSTCOMEFIRSTSERVE || scheduler.getScheduleType() == OSControl.Schedule_Type.SHORTEST_FIRST)
            {
                //this code validates that each process can write its own name into appropriate pages
//                ArrayList<PageTableEntry> processPTEs = process.getMemory();
//                memory.writeToMemory(processPTEs.get(0), process.getProcessName());
//                memory.freePages(process.getProcessID());

//                    //testing write to memory - it works
//                    ArrayList<PageTableEntry> processPTEs = process.getMemory();
//                    //write two chunks of data to same page (page 0)
//                    memory.writeToMemory(processPTEs.get(0), new byte[]{99,98,97,96,95});
//                    memory.writeToMemory(processPTEs.get(0), new byte[]{9,8,7,6,5});
//                    //write two chunks of data to same page (page 1)
//                    memory.writeToMemory(processPTEs.get(1), new byte[]{88,87,86,85,84});
//                    memory.writeToMemory(processPTEs.get(1), new byte[]{91,81,71,61,51});



                //process runs to completion on first run
                System.out.println("FCFS: " + process.getProcessName() + "ran to completion.");
                process.setRemainingTime(0);  //process runs to completion (FirstComeFirstServe)
            }
            //ROUND ROBIN PROCESS HANDLING
            else if (scheduler.getScheduleType() == OSControl.Schedule_Type.ROUND_ROBIN)
            {
                //process gets 'quantum' run time and is then placed back in queue if remainingTime is not <= 0
                Double remainingTime = process.getRemainingTime();
                Double quantum = OSControl.getInstance().getQuantum();

                if (remainingTime > quantum)
                {
                    remainingTime -= quantum; //runt for Quantum TIME
                    process.setRemainingTime(remainingTime);
                    scheduler.addProcess(process); //put process back in scheduler queue
                }
                else
                {
                    remainingTime = 0.0;
                    System.out.println(process.getProcessName() + " process completed.");
                }
            }
            //PRIORITY PROCESS HANDLING
            else if (scheduler.getScheduleType() == OSControl.Schedule_Type.PRIORITY)
            {
                //run highest priority process, giving it 'quantum' run time
                Double remainingTime = process.getRemainingTime();
                Double quantum = OSControl.getInstance().getQuantum();

                if (remainingTime > quantum)
                {
                    remainingTime -= quantum;
                    process.setRemainingTime(remainingTime);
                    scheduler.addProcess(process);
                }
                else
                {
                    remainingTime = 0.0;
                    process.setRemainingTime(remainingTime);

                    System.out.println(process.getProcessName() + " process completed.");
                }
            }
            //SHORTEST FIRST PROCESS HANDLING
            else if (scheduler.getScheduleType() == OSControl.Schedule_Type.SHORTEST_FIRST)
            {
                //TODO
            }
        }
        System.out.println("No More Processes");
    }
}
