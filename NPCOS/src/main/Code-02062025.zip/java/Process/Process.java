package Process;

import OSCore.OSControl;

import java.util.ArrayList;

enum State {None, New, Ready, Running, Waiting, Terminated};

public class Process
{
    Integer processID;
    String processName;
    Integer parentID;
    Integer userID;
    State processState;
    String programCounter;
    double remainingTime;

    String EAX;
    String EBX;
    String ECX;
    String EDX;
    Integer processPriority;

    String Memory;

    ArrayList<Thread> threads;

    public Process()
    {
        processID = OSControl.getInstance().getNEXT_PROCESS_ID();
        remainingTime = (double) (Math.random() * 50) + 1;
    }

    public Integer getProcessPriority()
    {
        return processPriority;
    }

    public double getRemainingTime()
    {
        return remainingTime;
    }

    public String getProcessName()
    {
        return processName;
    }

    public void setRemainingTime(double remainingTime)
    {
        this.remainingTime = remainingTime;
    }
}
