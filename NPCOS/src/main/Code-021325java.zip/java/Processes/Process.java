package Processes;

import OSCore.OSControl;

import java.util.ArrayList;

enum State {None, New, Ready, Running, Waiting, Terminated};

public class Process
{
    Integer processID;
    String processName;
    Integer parentID;
    Integer userID;
    State processState;
    String programCounter;
    double burstTime;  //time remaining to complete execution

    String EAX;
    String EBX;
    String ECX;
    String EDX;
    Integer processPriority;
    ArrayList<Thread> threads;

    public Process(String name)
    {
        processID = OSControl.getInstance().getNEXT_PROCESS_ID();
        burstTime = (double) (Math.random() * 50) + 1;
        processState = State.Ready;
        processName = name;
    }

    public Process(String name, Integer priority)
    {
        processID = OSControl.getInstance().getNEXT_PROCESS_ID();
        burstTime = (double) (Math.random() * 50) + 1;
        processState = State.Ready;
        processName = name;
        processPriority = priority;
    }
    public Integer getProcessPriority()
    {
        return processPriority;
    }

    public double getBurstTime()
    {
        return burstTime;
    }

    public void setBurstTime(double burstTime)
    {
        this.burstTime = burstTime;
    }

    public String getProcessName()
    {
        return processName;
    }

    public Integer getProcessID() {
        return processID;
    }
}
