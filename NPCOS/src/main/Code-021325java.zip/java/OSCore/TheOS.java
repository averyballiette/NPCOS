package OSCore;
import Processes.Process;

import java.util.Random;

public class TheOS
{
    public static void main(String[] args)
    {
        CentralProcessor cpu = new CentralProcessor();
        Scheduler scheduler = Scheduler.getInstance();

        for (int i = 0; i<2; i++)
            //scheduler.addProcess(new Process("TheProcess"));
            //scheduler.addProcess(new Process("TheProcess"+i, new Random().nextInt(10))); //random priority
            scheduler.addProcess(new Process("TheProcess"+i, 5));  //fixed priority

        cpu.run();

    }
}
